import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec; 
import javax.crypto.spec.SecretKeySpec;

// In this version IV is initialised by cipher object itself, but it can be extracted by
// getIV method and used later with decryption;  

public class DES_CBC_getIV
{
	public static void main(String[] args)
	{
		try
		{
                //Lookup a key generator for the DES cipher
                        KeyGenerator kg = KeyGenerator.getInstance("DES");
			SecretKey key = kg.generateKey();

			SecretKeySpec keySpec = new
                        SecretKeySpec(key.getEncoded(), "DES");		
                //Lookup an instance of a DES cipher
			Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
                
                
                 
                  
               
               //Initialize the cipher using the secter key

			cipher.init(Cipher.ENCRYPT_MODE, keySpec);
		
               // Get IV used by the cipher; this value should be used in decryption.                
                
                IvParameterSpec ivSpec = new IvParameterSpec(cipher.getIV());   
                
                //Message to encrypt
	                String plainText = "This is a secret!";
                        
                        
                //Sequence of byte to encrypt 
                
                        
                        
		
                //Encrypt the message		
			byte[] cipherText = cipher.doFinal(plainText.getBytes());
				
			System.out.println("Resulting Cipher Text:\n");
			for(int i=0;i<cipherText.length;i++)
			{
				System.out.print(cipherText[i] + " ");
			}
			System.out.println("");
                        
                        
                        
                        
			
		} catch (Exception e)
		{
			e.printStackTrace();
		}
	}
}
